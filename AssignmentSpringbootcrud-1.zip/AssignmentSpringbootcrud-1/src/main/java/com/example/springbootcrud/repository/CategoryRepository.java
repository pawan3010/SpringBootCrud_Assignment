package com.example.springbootcrud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springbootcrud.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}
