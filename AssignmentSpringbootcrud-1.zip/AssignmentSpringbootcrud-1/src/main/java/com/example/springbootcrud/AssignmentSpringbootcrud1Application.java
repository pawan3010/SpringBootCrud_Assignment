package com.example.springbootcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentSpringbootcrud1Application {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentSpringbootcrud1Application.class, args);
	}

}
